#include "Image.h"
#include "Pixel.h"


#include <stdlib.h>
#include <cassert>
#include <fstream>
#include <string>


#include <iostream>
using namespace std;


Image::Image (){
    tab = nullptr;
    dimx= 0;
    dimy= 0;
}

Image::Image (unsigned int dimensionX,unsigned int dimensionY){
    assert(dimensionX >=0  && dimensionY >=0);
    dimx= dimensionX;
    dimy= dimensionY;
    tab = new Pixel [dimx*dimy]; 
}


Image::~Image (){
    delete[] tab;
    dimx= 0;
    dimy= 0;
}

Pixel& Image::getPix(unsigned int x, unsigned int y)const{
    assert(x < dimx);
    assert(y < dimy);
    return tab[y*dimx+x];

}

void Image::setPix(const unsigned int x, const unsigned int y, const Pixel& p){
    assert(x<dimx && y<dimy);
    tab[y*dimx+x]= p;
}

void Image::dessinerRectangle(const unsigned int Xmin,const unsigned int Ymin,const unsigned int Xmax,const unsigned int Ymax,const Pixel& p){
    assert(Xmin<=Xmax);
    assert(Ymin<=Ymax);
    assert(Xmin<dimx);
    assert(Ymin<dimy);
    assert(Xmax<dimx);
    assert(Ymax<dimy);

    for(unsigned int j=0; j< Ymax-Ymin; j++){
        for(unsigned int i=0; i< Xmax-Xmin; i++){
            setPix(Xmin +i,Ymin + j, p);
        }
    }
}

void Image::effacer(const Pixel& p){
    dessinerRectangle(0,0, dimx-1, dimy-1,p);
}

void Image::testRegression ()
{
    assert(dimx==0 && dimy==0);

    Image im(21,32);
    Pixel p(25,120,62);
    Pixel p2(23,100,75);

    //verification taille image 
    assert(im.dimx==21 && im.dimy==32);

    //verification get, set, dessinrectangle, effacer
    im.setPix(16,15,p);

    assert(im.getPix(16,15).getRouge() == 25);
    assert(im.getPix(16,15).getVert() == 120);
    assert(im.getPix(16,15).getBleu() == 62);  

    im.dessinerRectangle(0,0,4,4,p);
    
    for (unsigned int i = 0; i < 4; i++)
    {
        for (unsigned int j = 0; j < 4; j++)
        {
            assert(im.getPix(i,j).getRouge() == 25);
            assert(im.getPix(i,j).getVert() == 120);
            assert(im.getPix(i,j).getBleu() == 62); 
        }
    }

    im.effacer(p2);

    for (unsigned int i = 0; i < 20; i++)
    {
        for (unsigned int j = 0; j < 31; j++)
        {
            assert(im.getPix(i,j).getRouge() == 23);
            assert(im.getPix(i,j).getVert() == 100);
            assert(im.getPix(i,j).getBleu() == 75); 
        }
    }

    
     
    //verification coleur pixel
    assert(p.getRouge() == 25);
	assert(p.getVert() == 120);
	assert(p.getBleu() == 62);



}


void Image::sauver(const string & filename) const {
    ofstream fichier(filename.c_str());
    assert(fichier.is_open());

    fichier << "P3" << endl;
    fichier << dimx << " " << dimy << endl;
    fichier << "255" << endl;

    for ( unsigned int y = 0; y < dimy; ++y) {
        for ( unsigned int x = 0; x < dimx; ++x) {
            Pixel &pix = getPix(x, y);
            fichier << +pix.getRouge() << " " << +pix.getVert() << " " << +pix.getBleu() << " ";
        }
    }
    cout << "Sauvegarde de l'image " << filename << " ... OK\n";
    fichier.close();
}


void Image::ouvrir(const string & filename) {
    ifstream fichier (filename.c_str());
    assert(fichier.is_open());

	unsigned char r,g,b;
	string mot;

	fichier >> mot >> dimx >> dimy >> mot;
	assert(dimx > 0 && dimy > 0);

	if (tab != NULL) delete [] tab;
	tab = new Pixel [dimx*dimy];

    for(unsigned  int y=0; y<dimy; ++y){
        for(unsigned int x=0; x<dimx; ++x) {
            fichier >> r >> b >> g;
            getPix(x,y).setRouge(r);
            getPix(x,y).setVert(g);
            getPix(x,y).setBleu(b);
        }
    }
    fichier.close();
    cout << "Lecture de l'image " << filename << " ... OK\n";
}

void Image::afficherConsole(){
    cout <<"dimx = " <<dimx << " ;dimy= " << dimy << endl;
    
    for(unsigned int x=0; x<dimx; x++) {
        for(unsigned int y=0; y<dimy; y++) {
            Pixel pix = getPix(x,y);
            cout <<"["<< +pix.getRouge() << " " << +pix.getVert() << " " << +pix.getBleu() << "] ";
        }
        cout << endl;
    }
}

void Image::afficher(){
    afficherInit();
    afficherBoucle();
    afficherDetruit();
}

void Image::afficherInit(){
    window = SDL_CreateWindow("Image", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 200, 200, SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE);
    if (window == nullptr) {
        cout << "Erreur lors de la creation de la fenetre : " << SDL_GetError() << endl; 
        SDL_Quit(); 
        exit(1);
    }

    renderer = SDL_CreateRenderer(window,-1,0);

    SDL_SetRenderDrawColor(renderer, 211, 211, 211, 255);
    SDL_RenderClear(renderer);
    SDL_RenderPresent(renderer);

    renderer = SDL_CreateRenderer(window,-1,0);
    
    sauver("./data/Image.ppm");
	surface = IMG_Load("./data/Image.ppm");

    texture = SDL_CreateTextureFromSurface(renderer,surface);

}

void Image::afficherBoucle(){

}

void Image::afficherDetruit(){

}



