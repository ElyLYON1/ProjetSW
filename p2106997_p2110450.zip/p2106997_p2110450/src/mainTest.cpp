#include "Image.h"
 
int main() {
   Image monImage;
   monImage.testRegression();
   return 0;
}